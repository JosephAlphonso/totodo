from django.conf.urls import url
from task_management import apiviews
from . import views as candidate_management_views
from . import online_exam_views
from .views import *

urlpatterns = [
    url(r'^get_programme_details/$',candidate_management_views.get_programme_details,name="get_programme_details"),
    url(r'^get_batch_details/$',candidate_management_views.get_batch_details,name="get_batch_details"),
    url(r'^get_subject_batch_details/$',candidate_management_views.get_subject_batch_details,name="get_subject_batch_details"),
    url(r'^getcandidatefilter/$',candidate_management_views.getcandidatefilter,name="getcandidatefilter"),
    url(r'^check_avail_user/$', candidate_management_views.check_avail_user, name='check_avail_user'),

]

# Urls for online exam test

urlpatterns += [
    url(r'^login/$',online_exam_views.login,name="login"),
    url(r'^timer/$',online_exam_views.timer,name="timer"),
    url(r'^warning/$',online_exam_views.warning,name="warning"),
    url(r'^online/$',online_exam_views.online_exam,name="online_exam"),
    url(r'^online/get_qp/$',online_exam_views.get_exam_qp.as_view(),name="get_qp"),
    url(r'^online/results/$',online_exam_views.results,name="results"),
    url(r'^online/results/review/$',online_exam_views.review,name="review"),
    url(r'^online/results/feedback/$',online_exam_views.feedback,name="feedback"),
]

urlpatterns += [
    url(r'^$', index),
    url(r'^candidate_details_table/$',CandidateDetailsView.as_view(),name="candidate_details_table"),
    url(r'^candidate_details_form/$',CandidateDetailsForm.as_view(),name="candidate_details_form"),
    url(r'^parent_details_table/$',ParentDetailsView.as_view(),name="parent_details_table"),
    url(r'^parent_details_form_new/$',ParentDetailsForm.as_view(),name="parent_details_form"),
    url(r'^candidate_batch_map_table/$',CandidateBatchMapView.as_view(),name="candidate_batch_map_table"),
    url(r'^candidate_batch_map_form/$',CandidateBatchMapForm.as_view(),name="candidate_batch_map_form"),
    url(r'^delete_data/$', delete_data, name="delete_data"),
    url(r'^get_candidates/$', get_candidates, name="get_candidates"),
]