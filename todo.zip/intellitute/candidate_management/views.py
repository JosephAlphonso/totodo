from django.shortcuts import render
from django.shortcuts import render, render_to_response, redirect
from django.http import HttpResponse
from django.http import JsonResponse
from task_management import methods  as  task_management_methods
from django.views import View
from task_management.models import  QpMaster,TaskMaster
from course_management.models import SubjectBatchMap
from course_management import methods as course_management_methods
# from .methods import getTaskCreation,dvs_save_data
from course_management import models as course_management_models
from candidate_management import models as candidate_management_models
from user_management import models as user_management_models
from django.db import IntegrityError
import json
import pdb
import pytz
import datetime
import traceback
import logging
from django.contrib.auth.models import User
from user_management.models import CommonFields, TITLE,OrganizationDetail
intellitute_logger = logging.getLogger('intellitute')
intellitute_except_logger = logging.getLogger('intellitute_except')
from .models import *

def get_programme_details(request):
    response_dict = {}
    try:
        organization_pk = request.GET.get("organization_pk")
        programme_ids = course_management_models.OrganizationProgramMap.objects.filter(organizations_id = organization_pk).values_list("programme",flat=True)
        prog_data = course_management_models.ProgrammeDetail.objects.filter(pk__in = programme_ids).values("pk","name")
        response_dict.update({"prog_data" : list(prog_data)})
    except Exception as e:
        intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
    return JsonResponse(response_dict)

def get_batch_details(request):
    response_dict = {}
    try:
        prog_pk = request.GET.get("prog_pk")
        batch_data = course_management_models.BatchDetail.objects.filter(programme_id = prog_pk).values("pk","name")
        response_dict.update({"batch_data" : list(batch_data)})
    except Exception as e:
        intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
    return JsonResponse(response_dict)

def get_subject_batch_details(request):
    response_dict = {}
    try:
        batch_pk = request.GET.get("batch_pk")
        subject_batch_data = course_management_models.SubjectBatchMap.objects.filter(batch_id = batch_pk).values("pk","subject_name")
        response_dict.update({"subject_batch_data" : list(subject_batch_data)})
    except Exception as e:
        intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
    return JsonResponse(response_dict)

def getcandidatefilter(request):
    try:
        batch_id  = request.GET.get('batch_id', None)
        programme_id = request.GET.get('programme_id', None)
        candidate_programme = candidate_management_models.CandidateProgrammeMap.objects.filter()
        if request.GET.get('programme_id', None):
            batchlist  = course_management_models.BatchDetail.objects.filter(programme=request.GET.get('programme_id'))
            candidate_programme = candidate_programme.filter(programme = request.GET.get('programme_id', None))
        if request.GET.get('batch_id', None):
            candidate_programme = candidate_programme.filter(programme__batch_detail_programme = request.GET.get('batch_id', None))
        candidate_detatil_list = list(candidate_programme.values(
                                        'candidate__first_name',
                                        'candidate__organization_id__name', 
                                        'candidate__email', 
                                        'candidate__phone', 
                                        'candidate__address', 
                                        'candidate__pk'))
        batchlist = list(batchlist.values('name', 'pk'))
        intellitute_logger.info("candidate_management \t getcandidatefilter \t candidate filter operations")
        return JsonResponse({"data":candidate_detatil_list, "batchlist":batchlist, "result":"success"})
    except Exception as e:
        intellitute_except_logger.critical('candidate_management \t getcandidatefilter \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return JsonResponse({"data":[], "result":"error"})

def check_avail_user(request):
    """ Method used to check the existing User 
        input Username
        output bool True/False  
    """

    try:
        get_data = request.GET
        response_dict = {}
        user_name = get_data.get('user_name')
        
        if User.objects.filter(username__icontains= user_name).exists():
            Flag_ST = False
            response_dict.update({'action': 'data already available',
                                 'Flag': Flag_ST})
            intellitute_logger.info('CandidateManagement \t Check_avail_user \t  Data already available ')
            return HttpResponse(json.dumps(response_dict),
                                content_type='application/javascript',
                                status=200)
        else:
            Flag_ST = True
            response_dict.update({'action': 'New data',
                                 'Flag': Flag_ST})
            intellitute_logger.info('CandidateManagement \t Check_avail_user \t  New Data')
            return HttpResponse(json.dumps(response_dict),
                                content_type='application/javascript',
                                status=200)
    except Exception as e:

        intellitute_except_logger.critical(str(e) + '\n'
                + str(traceback.format_exc()))
        response_dict.update({'Flag_status': 'Error'})
        intellitute_except_logger.critical("CandidateManagement \t Check_avail_user \t %s " % str(e))
        return HttpResponse(json.dumps(response_dict),
                            content_type='application/javascript',
                            status=200)

##################joseph's code starts here###################

def index(request):
    """ function to get main template """
    context = {}
    try:
        data =  content.contents['candidate_management']
        intellitute_logger.info("data 1st time %s " % str(data))
        perm_list =[pl.split('_')[-1] for pl in request.user.get_all_permissions()]
        for con in data:
            if "display" in con.keys():
                con.pop("display")
            if not con.get('label') in perm_list:
                con.update({"display":"display:none"})
        intellitute_logger.info("data %s " % str(data))
        context.update({"content":data})
        intellitute_logger.info(
            "Contexts of ")
        return render(request,'candidate_management.html',context=context)
    except Exception as e:
        intellitute_except_logger.critical(e)
        return render(request,'candidate_management.html',context=context)

class CandidateDetailsView(View):

    def get(self,request):
        context = {}
        try:
            context.update({
                "candidate_data": candidate_management_models.CandidateDetail.objects.filter(status = True).order_by("-created_on"),
                "batch_data":  course_management_models.BatchDetail.objects.filter(status = True).order_by("-created_on"),
                "programme_data": candidate_management_models.ProgrammeDetail.objects.filter(status = True).order_by("-created_on")
                })
        except Exception as e:
            intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return render(request, "candidate_details_table.html",content_type='text/html',context=context)

    def post(self,request):
        candidate_edit_id = request.POST.get("edit_id")
        if candidate_edit_id:               
            candidate_obj,candidate_obj_created = candidate_management_models.CandidateDetail.objects.update_or_create(pk = candidate_edit_id,
            defaults={"title" : request.POST.get("title"),
            "first_name" : request.POST.get("first_name"),
            "last_name" : request.POST.get("last_name"),
            "email" : request.POST.get("email"),
            "phone" : request.POST.get("phone"),
            "parent_name" : request.POST.get("parent_name"),
            "address" : request.POST.get("address"),
            "dob" : pytz.utc.localize(datetime.datetime.strptime(request.POST.get("dob"),'%d %B, %Y')),
            "created_by" :request.user.pk})

            organization_programme_map = course_management_models.OrganizationProgramMap.objects.get(organizations_id = request.POST.get("organization_id"),programme_id = request.POST.get("programme_id"))
            candidatestatus_obj, candidatestatus_created = candidate_management_models.CandidateStatus.objects.update_or_create(name = "Active", defaults={"code" : 'ACT',"name":'Active',"created_by" : request.user.id},)

            candidate_programme_map, candidate_programme_created = candidate_management_models.CandidateProgrammeMap.objects.update_or_create(candidate = candidate_obj,
                defaults={"candidate_status" : candidatestatus_obj,
                "organization_program" : organization_programme_map,
                "created_by" : request.user.pk}
                )
            return JsonResponse({"status":"updated"})

        else:
            user = User.objects.create_user(
                request.POST.get("user").lower(),
                request.POST.get("email"),
                "admin123")
            user.save()
            candidate_data = candidate_management_models.CandidateDetail(
                title = request.POST.get("title"),
                first_name = request.POST.get("first_name"),
                last_name = request.POST.get("last_name"),
                email = request.POST.get("email"),
                phone = request.POST.get("phone"),
                parent_name = request.POST.get("parent_name"),
                address = request.POST.get("address"),
                user = user,
                dob = pytz.utc.localize(datetime.datetime.strptime(request.POST.get("dob"),'%d %B, %Y')),
                created_by = request.user.pk,
                )
            candidate_data.save()

            organization_programme_map = course_management_models.OrganizationProgramMap.objects.get(organizations_id = request.POST.get("organization_id"),programme_id = request.POST.get("programme_id"))
            candidatestatus_obj, created = candidate_management_models.CandidateStatus.objects.update_or_create(name = "Active", defaults={"code" : 'ACT',"name":'Active',"created_by" : request.user.id},)
            candidate_programme_map = candidate_management_models.CandidateProgrammeMap(
                candidate = candidate_data,
                organization_program = organization_programme_map,
                candidate_status = candidatestatus_obj,
                created_by = request.user.pk,
                )
            candidate_programme_map.save()
            return JsonResponse({"status":"created"})


class CandidateDetailsForm(View):
    def get(self,request):
        try:
            context = {
                    "user_data": User.objects.all(),
                    "title":TITLE,
                    "organization":OrganizationDetail.objects.filter(status = True),
                    "academicyear": candidate_management_models.AcademicYear.objects.filter(status = True),
                    }
            edit_id = request.GET.get('edit_id',None)
            if edit_id:
                response_dict = {}
                candidate_obj = candidate_management_models.CandidateDetail.objects.get(pk=request.GET.get('edit_id'))
                user_obj = User.objects.get(pk=candidate_obj.user_id)
                candidate_programmemap_obj = candidate_management_models.CandidateProgrammeMap.objects.get(candidate = candidate_obj)
                ProgrammeDetail = course_management_models.ProgrammeDetail.objects.filter(status = True)
                programme_ids = course_management_models.OrganizationProgramMap.objects.filter(organizations_id = candidate_programmemap_obj.organization_program.organizations_id).values_list("programme",flat=True)
                prog_data = course_management_models.ProgrammeDetail.objects.filter(pk__in = programme_ids).values("pk","name")
                response_dict.update({
                                "edit_id" : edit_id,
                                "first_name" : candidate_obj.first_name,
                                "address" : candidate_obj.address,
                                "dob" : candidate_obj.dob.__str__(),
                                "email" : candidate_obj.email,
                                "last_name" : candidate_obj.last_name,
                                "middle_name" : candidate_obj.middle_name,
                                "phone" : candidate_obj.phone,
                                #"photo" : candidate_obj.photo,
                                "status" : candidate_obj.status,
                                "title1" : candidate_obj.title,
                                "user_id" : candidate_obj.user_id,
                                "pk" : candidate_obj.pk,
                                "username" : user_obj.username,
                                "organizations_id" : candidate_programmemap_obj.organization_program.organizations_id,
                                "programme_id" : candidate_programmemap_obj.organization_program.programme_id,
                                "prog_data":list(prog_data)
                })


                return JsonResponse(response_dict)

        except Exception as e:
            intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return render(request, "forms/candidate_details_form.html",context=context)

class ParentDetailsView(View):
    def get(self,request):
        context = {}
        try:
            context.update({
                "parent_data": candidate_management_models.ParentDetail.objects.filter(status = True).order_by("-created_on"),
                })
        except Exception as e:
            intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return render(request, "parent_details_table.html",content_type='text/html',context=context)

    def post(self,request):
        parent_edit_id = request.POST.get("edit_id")
        if parent_edit_id:
            response_dict = {}
            parent_obj = candidate_management_models.ParentDetail.objects.get(pk = parent_edit_id)
            parent_obj.title = request.POST.get("title")
            parent_obj.first_name = request.POST.get("first_name")
            parent_obj.last_name = request.POST.get("last_name")
            parent_obj.email = request.POST.get("email")
            parent_obj.phone = request.POST.get("phone")
            parent_obj.address = request.POST.get("address")
            parent_obj.created_by = request.user.pk
            parent_obj.save()

            existing_candidate_ids = list(candidate_management_models.CandidateParentMap.objects.filter(parent=parent_obj).values_list('candidate',flat=True))
            request_candidate_ids_list = request.POST.getlist('candidate_ids')
            request_candidate_ids_list = list(map(int, request_candidate_ids_list))
            avoid_candidate_ids_list = list(set(existing_candidate_ids).intersection(set(request_candidate_ids_list)))
            new_candidate_ids_list = list(set(request_candidate_ids_list).difference(set(avoid_candidate_ids_list)))
            delete_candidate_ids_list = list(set(existing_candidate_ids).difference(set(avoid_candidate_ids_list)))

            candidate_management_models.CandidateParentMap.objects.filter(candidate_id__in=delete_candidate_ids_list).delete()
            for each in new_candidate_ids_list:
                candidate_programme_map = candidate_management_models.CandidateParentMap(
                    candidate = candidate_management_models.CandidateDetail.objects.get(pk = each),
                    parent = parent_obj,
                    created_by = request.user.pk,
                    )
                candidate_programme_map.save()
            
            return JsonResponse({"status":"updated"})
        else:
            user = User.objects.create_user(
                request.POST.get("user").lower(),
                request.POST.get("email"),
                "admin123")
            user.save()


            parent_data = candidate_management_models.ParentDetail(
                title = request.POST.get("title"),
                first_name = request.POST.get("first_name"),
                last_name = request.POST.get("last_name"),
                email = request.POST.get("email"),
                phone = request.POST.get("phone"),
                address = request.POST.get("address"),
                user = user,
                created_by = request.user.pk,
                )
            parent_data.save()
            
            candidate_ids_list = request.POST.getlist('candidate_ids')
            
            
            for each in candidate_ids_list:
                candidate_programme_map = candidate_management_models.CandidateParentMap(
                    candidate = candidate_management_models.CandidateDetail.objects.get(pk = each),
                    parent = parent_data,
                    created_by = request.user.pk,
                    )
                candidate_programme_map.save()

            return JsonResponse({"status":"created"})

class ParentDetailsForm(View):
    def get(self,request):
        try:
            context = {
                    "user_data": User.objects.all(),
                    "title":TITLE,
                    "organization":OrganizationDetail.objects.filter(status = True),
                    "ProgrammeDetail":course_management_models.ProgrammeDetail.objects.filter(status = True),
                    "candidate":candidate_management_models.CandidateDetail.objects.filter(status = True).exclude(pk__in = candidate_management_models.CandidateParentMap.objects.filter(status=True).values_list('candidate_id',flat=True)).order_by("-created_on")
                    }
            edit_id = request.GET.get('edit_id',None)
            if edit_id:
                response_dict = {}
                parent_obj = candidate_management_models.ParentDetail.objects.get(pk=request.GET.get('edit_id'))
                user_obj = User.objects.get(pk=parent_obj.user_id)
                candidate_ids = list(candidate_management_models.CandidateParentMap.objects.filter(parent=parent_obj).values_list('candidate',flat=True))
                all_candidate_ids = list(candidate_management_models.CandidateParentMap.objects.filter(status=True).values_list('candidate_id',flat=True))
                exclude_candidate_id_list = list(set(all_candidate_ids).difference(set(candidate_ids)))

                response_dict.update({
                                "edit_id" : edit_id,
                                "first_name" : parent_obj.first_name,
                                "title1" : parent_obj.title,
                                "email" : parent_obj.email,
                                "last_name" : parent_obj.last_name,
                                "address" : parent_obj.address,
                                "username" : user_obj.username,
                                "phone" : parent_obj.phone,
                                "candidate_ids" : candidate_ids,
                                "candidate":[{"first_name":i.first_name,"pk":i.pk} for i in candidate_management_models.CandidateDetail.objects.filter(status = True).exclude(pk__in = exclude_candidate_id_list).order_by("-created_on")]

                })
                return JsonResponse(response_dict)

        except Exception as e:
            intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return render(request, "forms/parent_details_form.html",content_type='text/html',context=context)

def delete_data(request):
    try:
        model_obj = eval(request.POST.get('model_name'))
        delete_ids = request.POST.getlist('delete_ids[]')
        if request.POST.get('model_name') == "CandidateBatchMap":
            res=[]
            for i in delete_ids:
                res.extend(i.split(','))
            delete_ids = res
    except Exception as er:
        intellitute_except_logger.critical('task_management \t delete_data \t Error %s ' % str(er))
        return JsonResponse({"delete_status": True, "message": str(er)})
    for each in delete_ids:
        try:
            model_obj.objects.update(pk = each,status = False)
        except ValueError as e:
            intellitute_logger.info("course_management \t delete_data %s"  % str(e))
            return JsonResponse({"delete_status": False, "message": str(e)})
    intellitute_logger.info('task_management \t delete_data \t called for common delete operation')
    return JsonResponse({"delete_status": True})

class CandidateBatchMapView(View):

    def get(self, request):
        try:
            candidate_batch_map_data = candidate_management_models.CandidateBatchMap.objects.filter(status=True).order_by('-created_on').values('pk','candidate__candidate__first_name','batch_master__name','batch_master')

            from collections import defaultdict
            res_de = defaultdict(list)
            for result in candidate_batch_map_data:
                res_de[(result['batch_master__name'],result['batch_master'])].append({"candidate_name":result['candidate__candidate__first_name'],'pk':result['pk']})
            result = dict(res_de)
        except Exception as er:
            candidate_batch_map_data = []
            intellitute_except_logger.critical('task_management \t get_candidates \t '+str(e) +'\n'+ str(traceback.format_exc()))
        return render(request, 'candidate_batch_map_table.html', context= {"candidate_batch_map_data":result})

    def post(self, request):
        batch_id = request.POST.get('batch_id')
        academic_year = request.POST.get('academic_year')
        candidate_ids = request.POST.getlist('candidate_id')
        candidate_ids = [int(i) for i in candidate_ids]

        if request.POST.get('edit_id'):

            if not isinstance(eval(request.POST.get('edit_id')), tuple):
                edit_ids = [eval(request.POST.get('edit_id'))]
            else:
                edit_ids = list(eval(request.POST.get('edit_id')))

            existing_candidate_ids = CandidateBatchMap.objects.filter(batch_master_id = batch_id).values_list('candidate',flat=True)
            temp_list = list(set(existing_candidate_ids).intersection(set(candidate_ids)))
            final_candidate_ids = list(set(candidate_ids)-set(temp_list))
            delete_candidate_ids = list(set(existing_candidate_ids)-set(temp_list))
            CandidateBatchMap.objects.filter(batch_master_id = batch_id,candidate_id__in = delete_candidate_ids).delete()

            for candidate_id in final_candidate_ids:
                candidate_obj = CandidateBatchMap(batch_master_id=batch_id,
                                candidate=CandidateProgrammeMap.objects.get(candidate_id=candidate_id),
                                academic_year_id=academic_year,
                                created_by=request.user.id)
                candidate_obj.save()
            return JsonResponse({"status":"updated"})
        else:
            for candidate_id in candidate_ids:
                candidate_obj = CandidateBatchMap(batch_master_id=batch_id,
                                candidate=CandidateProgrammeMap.objects.get(candidate_id=candidate_id),
                                academic_year_id=academic_year,
                                created_by=request.user.id)
                candidate_obj.save()
            return JsonResponse({"status":"created"})

class CandidateBatchMapForm(View):

    def get(self,request):
        try:
            if request.GET.get('edit_id'):
                if not isinstance(eval(request.GET.get('edit_id')), tuple):
                    edit_ids = [eval(request.GET.get('edit_id'))]
                else:
                    edit_ids = list(eval(request.GET.get('edit_id')))
                candidate_batch_map = CandidateBatchMap.objects.filter(pk__in = edit_ids).values('pk','candidate__candidate__first_name','batch_master__name','batch_master','candidate','academic_year')
                from collections import defaultdict
                res_de = defaultdict(list)
                for result in candidate_batch_map:
                    res_de['batch_candidates'].append({"candidate_name":result['candidate__candidate__first_name'],"candidate_pk":result['candidate'],'candidate_batch_map_pk':result['pk']})
                    res_de['batch_name'] = result['batch_master__name']
                    res_de['batch_pk'] = result['batch_master']
                    res_de['academic_year'] = result['academic_year']

                result = dict(res_de)
                return JsonResponse(result)

            candidate_details = candidate_management_models.CandidateDetail.objects.filter(status = True).exclude(pk__in = candidate_management_models.CandidateBatchMap.objects.filter(status=True).values_list('candidate_id__candidate_id',flat=True))
            batch_detail = BatchDetail.objects.filter(status= True)#.values('pk', 'name', 'start_date', 'end_date')
            intellitute_logger.info("course_management \t get_subjectbatchform \t called to display the subject batch form")
            return render(request, 'forms/candidate_batch_map_form.html', context={"candidate_details": candidate_details, "batch_detail": batch_detail,"academic_year": candidate_management_models.AcademicYear.objects.filter(status = True)})
        except Exception as er:
            intellitute_except_logger.critical('course_management \t get_subjectbatchform \t exceptions occured %s' % str(er))
            return render(request, 'forms/candidate_batch_map_form.html', context={"subject_details": [], "batch_details_list": [],"academic_year": []})

def get_candidates(request):
    response_dict = {}
    try:
        batch_pk = request.GET.get("batch_pk")
        exclude_subject_ids = CandidateBatchMap.objects.filter(status=True,batch_master_id = batch_pk).values_list("candidate__candidate_id",flat=True)
        res_candidate_detail = CandidateDetail.objects.filter(status=True).exclude(pk__in=exclude_subject_ids).values("pk","first_name")

        response_dict.update({"candidate_detail" : list(res_candidate_detail)})
    except Exception as e:
        intellitute_except_logger.critical('candidate_management \t get_subjects \t '+str(e) +'\n'+ str(traceback.format_exc()))
    return JsonResponse(response_dict)

##################joseph's code ends here###################