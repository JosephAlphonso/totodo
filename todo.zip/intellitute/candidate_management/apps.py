from django.apps import AppConfig


class CandidateManagementConfig(AppConfig):
    name = 'candidate_management'

    def ready(self):
        import candidate_management.signals