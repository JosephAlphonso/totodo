from django.views.generic.base import View
from django.http import JsonResponse,HttpResponse
import json
from django.views.decorators.csrf import csrf_exempt
import os
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.conf import settings
from django.shortcuts import render

# from item_bank.models import *
# For development
from qp_authoring.models import QuestionMaster


# Online exam module
def login(request):
    return render(request,'login.html',context={})

def timer(request):
    return render(request,'timer.html',context={})

def warning(request):
    return render(request,'warning.html',context={})

def online_exam(request):
    return render(request,'onlinetest.html',context={})

def results(request):
    return render(request,'exam-result.html',context={})

def review(request):
    return render(request,'review.html',context={})

def feedback(request):
    return render(request,'feedback.html',context={})

class get_exam_qp(View):
    def post(self,request):
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)
        qp_id = body['qp_id']
        qpsetlist = list(QuestionMaster.objects.filter(q_id=int(qp_id)).values('q_text'))
        return JsonResponse({"qp":qpsetlist})