from .serializers import CandidateSerializer,ParentDetailSerializer,CandidateParentMapSerializer
from .models import CandidateDetail
from user_management.models import FeatureGroupMap
from user_management.roles_config import roles_data
from .models import CandidateProgrammeMap,ParentDetail,CandidateParentMap


class StudenLogin:
    @classmethod
    def student_login(cls,request,user_obj):
        """
            student_login request.
            :returns: Josn-- the return code.
            :param name: request and user_obj.
            :type name: object.
        """
        
        std=CandidateDetail.objects.filter(user=user_obj).select_related()
        serializers = CandidateSerializer(std[0],context={"request": request})
        data=serializers.data
        d={}
        d['first_name']=data.get('first_name')
        d['last_name'] = data.get('last_name')
        d['middle_name'] = data.get('middle_name')
        d['email'] = data.get('email')
        d['dob'] = data.get('dob')
        d['photo'] = data.get('photo')
        d['phone'] = data.get('phone')
        d['address'] = data.get('address')
        d['parent_name'] = data.get('parent_name')
        d['parent_phone'] = data.get('parent_phone')
        d['parent_email'] = data.get('parent_email')
        d['org'] = data.get('candidate_program')[0].get('organization_program').get('organizations').get('name')
        d['prog_name'] = data.get('candidate_program')[0].get('organization_program').get('programme').get('name')
        # d['subjects'] = [i.get('subject').get('name') for i in  data.get('candidate_program')[0].get('candidate_programmemap_candidate')[0].get('batch_master').get('subject_batch_map')]
        profile_data=FeatureGroupMap.objects.filter(menu_group__name=roles_data.get('role_student')).values_list('menu__menu', flat=True)
        d.update({'last_login':user_obj.last_login.astimezone().strftime("%d-%m-%Y %H:%M %p")})
        d['profile_options']=profile_data
        user_group = user_obj.groups
        d['role']=user_group.values()[0].get('name')
        return d
        
class ParentLogin:
    @classmethod
    def parent_login(cls,request,user_obj):
        """
            parent_login request.
            :returns: Josn-- the return code.
            :param name: request and user_obj.
            :type name: object.
        """
        parent=ParentDetail.objects.filter(user=user_obj).select_related()
        serializers = ParentDetailSerializer(parent[0],context={"request": request})
        data=serializers.data
        profile_data=FeatureGroupMap.objects.filter(menu_group__name=roles_data.get('role_parent')).values_list('menu__menu', flat=True)
        data.update({'last_login':user_obj.last_login.astimezone().strftime("%d-%m-%Y %H:%M %p")})
        data['profile_options']=profile_data
        user_group = user_obj.groups
        data['role']=user_group.values()[0].get('name')
        # import ipdb; ipdb.set_trace()
        child = CandidateParentMap.objects.filter(parent=parent)
        child_data = CandidateParentMapSerializer(child,many=True).data
        final_list=[]
        for each in child_data:
            d={}
            d['child_id'] = each.get('candidate').get('user')
            d['first_name'] = each.get('candidate').get('first_name')
            d['last_name'] = each.get('candidate').get('last_name')
            d['program'] = each.get('candidate').get('candidate_program')[0].get('organization_program').get('programme').get('name')
            d['class'] = each.get('candidate').get('candidate_program')[0].get('candidate_programmemap_candidate')[0].get('batch_master').get('name')
            final_list.append(d)
        data['child'] = final_list
        return data
        