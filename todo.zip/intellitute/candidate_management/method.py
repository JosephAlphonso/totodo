from candidate_management import models as candidate_management_models

def getcandidatedetails(class_pk):
    candidate_data = list(candidate_management_models.CandidateProgrammeMap.objects.filter(
            candidate_classmap_candidate__class_detail = class_pk).values("candidate__pk","candidate__first_name"))
    return candidate_data