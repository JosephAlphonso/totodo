from rest_framework import serializers
from .models import CandidateBatchMap,OrganizationDetail,OrganizationProgramMap,CandidateParentMap,CandidateDetail,ParentDetail,CandidateClassMap,CandidateProgrammeMap
from course_management.models import ClassDetail,ProgrammeDetail,BatchDetail,SubjectBatchMap,SubjectDetail
from user_management.methods import is_Secure


class ProgrammeDetailDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model=ProgrammeDetail
        fields = ('name',)


class OrganizationDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model=OrganizationDetail
        fields = ('name',)

class OrganizationProgramMapSerializer(serializers.ModelSerializer):
    organizations = OrganizationDetailSerializer()
    programme=ProgrammeDetailDetailSerializer()
    class Meta:
        model=OrganizationProgramMap
        fields = ('organizations','programme')


class SubjectDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model=SubjectDetail
        fields = ('name',)

class SubjectBatchMapSerializer(serializers.ModelSerializer):
    subject = SubjectDetailSerializer()
    class Meta:
        model=SubjectBatchMap
        fields = ('subject',)

class BatchDetailSerializer(serializers.ModelSerializer):
    subject_batch_map = SubjectBatchMapSerializer(many=True)
    class Meta:
        model=BatchDetail
        fields = ('subject_batch_map',)


class CandidateBatchMapSerializer(serializers.ModelSerializer):
    batch_master=BatchDetailSerializer()
    class Meta:
        model=CandidateBatchMap
        fields = ('batch_master',)

class CandidateProgrammeMapSerializer(serializers.ModelSerializer):
    organization_program=OrganizationProgramMapSerializer()
    #candidate_programmemap_candidate = CandidateBatchMapSerializer(many=True)
    class Meta:
        model=CandidateProgrammeMap
        fields = ('organization_program',)

class CandidateSerializer(serializers.ModelSerializer):
    candidate_program=CandidateProgrammeMapSerializer(many=True)
    photo = serializers.SerializerMethodField('get_image',) 
    def get_image(self,obj):
        request = self.context.get('request')
        photo = obj.photo.url
        obj = is_Secure(request)+photo
        return obj
    class Meta:
        model = CandidateDetail
        fields = ('candidate_program','first_name','last_name','middle_name','email','dob','photo','phone','address','parent_name','parent_phone','parent_email')


class ParentDetailSerializer(serializers.ModelSerializer):
    """This is a ParentDetailSerializer class.

    """
    photo = serializers.SerializerMethodField('get_image',)
    def get_image(self,obj):
        request = self.context.get('request')
        photo = obj.photo.url
        obj = is_Secure(request)+photo
        return obj

    class Meta:
        model = ParentDetail
        fields = ('title','first_name','last_name','middle_name','email','phone','address','photo')


#parent child information
class ProgrammeDetailDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model=ProgrammeDetail
        fields = ('name',)


class OrganizationProgramMapSerializer(serializers.ModelSerializer):
    programme=ProgrammeDetailDetailSerializer()
    class Meta:
        model=OrganizationProgramMap
        fields = ('programme',)

class BatchDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model=BatchDetail
        fields = ('name',)
class CandidateBatchMapSerializer(serializers.ModelSerializer):
    batch_master=BatchDetailSerializer()
    class Meta:
        model=CandidateBatchMap
        fields = ('batch_master',)

class CandidateProgrammeMapSerializer(serializers.ModelSerializer):
    organization_program=OrganizationProgramMapSerializer()
    candidate_programmemap_candidate = CandidateBatchMapSerializer(many=True)
    class Meta:
        model=CandidateProgrammeMap
        fields = ('organization_program','candidate_programmemap_candidate')

class CanDetailSerializer(serializers.ModelSerializer):
    candidate_program = CandidateProgrammeMapSerializer(read_only=True,many=True)
    class Meta:
        model = CandidateDetail
        fields = ('user','first_name','last_name','candidate_program')

class CandidateParentMapSerializer(serializers.ModelSerializer):
    candidate = CanDetailSerializer()
    class Meta:
        model = CandidateParentMap
        fields = ('candidate',)