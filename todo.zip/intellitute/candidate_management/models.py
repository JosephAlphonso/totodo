from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.core.validators import RegexValidator
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User
from user_management.models import CommonFields, TITLE, BOOL_CHOICES,OrganizationDetail,ErrorInfo,unique_name,unique_code,unique_email
from course_management.models import ProgrammeDetail, ClassDetail,BatchDetail,SubjectBatchMap, OrganizationProgramMap
import os
from django.core.files.storage import FileSystemStorage
from django.conf import settings
# Create your models here.
from django.contrib.auth.models import User, Group

class CandidateStatus(CommonFields):
    code = models.CharField(max_length=20)
    name = models.CharField(max_length=50)

    def __str__(self):
        return "%s" %(self.name)

    def clean(self):
        if not self.validation_method():
            pass        

    def validation_method(self):
        if self.__class__.objects.filter(name__icontains=self.name, status=True).exclude(pk=self.pk).exists():
            raise ValidationError(
               unique_name,
            )
        elif self.code and self.__class__.objects.filter(code__icontains=self.code, status=True).exclude(pk=self.pk).exists():
            raise ValidationError(
                unique_code,
            )
        return True
    
    def save(self, *args, **kwargs):
        self.validation_method()
        super().save(*args, **kwargs)

class CandidateDetail(CommonFields):
    title = models.IntegerField(choices=TITLE)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100, null=True, blank=True)
    email = models.CharField(max_length=254, blank=True, null=True,validators=[validate_email])
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone = models.CharField(validators=[phone_regex], max_length=17, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    parent_name = models.CharField(max_length=100, null=True, blank=True)
    parent_phone = models.CharField(validators=[phone_regex], max_length=17, null=True, blank=True)
    parent_email = models.CharField(max_length=254, blank=True, null=True,validators=[validate_email])
    user = models.OneToOneField(User, related_name='user_candidatedetails', on_delete=models.PROTECT)
    photo=models.ImageField(
        storage=FileSystemStorage(location=settings.MEDIA_ROOT),         
        upload_to = os.path.join('candidate','photo'),
        blank=True,
        null=True) 
    dob = models.DateField()     
    class Meta:
        app_label = 'candidate_management'

    def __str__(self):
        return "%s" %(self.first_name)


    def validation_method(self):
        if self.__class__.objects.filter(email__icontains=self.email, status=True).exclude(pk=self.pk).exists():
            raise ValidationError(
                unique_email,
            )
        elif self.__class__.objects.filter(phone__icontains=self.phone, status=True).exclude(pk=self.pk).exists():
            raise ValidationError(
                unique_email,
            )
        return True
    
    def save(self, *args, **kwargs):
        self.validation_method()
        super().save(*args, **kwargs)


class CandidateProgrammeMap(CommonFields):
    candidate = models.ForeignKey(CandidateDetail, related_name='candidate_program', on_delete=models.PROTECT)
    organization_program = models.ForeignKey(OrganizationProgramMap, related_name='org_program_candidate', on_delete=models.PROTECT)
    candidate_status = models.ForeignKey(CandidateStatus, related_name='candidatemap_status', on_delete=models.PROTECT)

    class Meta:
        app_label = 'candidate_management'

    def __str__(self):
        return "%s-%s" %(self.organization_program, self.candidate)

    def clean(self):
        if not self.validation_method():
            pass        

    def validation_method(self):
        if self.__class__.objects.filter(organization_program=self.organization_program, candidate=self.candidate,\
                                        candidate_status=self.candidate_status, status=True).exclude(pk=self.pk).exists():
            raise ValidationError(
               unique_name,
            )
        return True
    
    def save(self, *args, **kwargs):
        self.validation_method()
        super().save(*args, **kwargs)


class ParentDetail(CommonFields):
    title = models.IntegerField(choices=TITLE)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100,null=True,blank=True)
    middle_name = models.CharField(max_length=100, null=True, blank=True)
    email = models.CharField(max_length=254, blank=True, null=True,validators=[validate_email])
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
    phone = models.CharField(validators=[phone_regex], max_length=17, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    user = models.OneToOneField(User, related_name='user_parentdetails', on_delete=models.PROTECT)
    photo=models.ImageField(
        storage=FileSystemStorage(location=settings.MEDIA_ROOT),         
        upload_to = os.path.join('parent','photo'),
        blank=True,
        null=True) 
    class Meta:
        app_label = 'candidate_management'

    def __str__(self):
        return "%s" %(self.first_name)

    def get_candidates_data(self):
        temp = ""
        for each in self.parent_candidateparentmap.all():
            if temp:
                temp = temp + "," +each.candidate.first_name
            else:
                temp = each.candidate.first_name
        return temp


class CandidateParentMap(CommonFields):
    parent = models.ForeignKey(ParentDetail, related_name='parent_candidateparentmap', on_delete=models.PROTECT)
    candidate = models.ForeignKey(CandidateDetail, related_name='candidate_candidateparentmap', on_delete=models.PROTECT)

    class Meta:
         app_label = 'candidate_management'
         unique_together = ('parent', 'candidate')

        

    def __str__(self):
        return "%s - %s" %(self.candidate, self.parent)

class AcademicYear(CommonFields):
    date=models.DateField()
    duration=models.IntegerField()
    class Meta:
         app_label = 'candidate_management'        

    def __str__(self):
        return str(self.duration)

class CandidateBatchMap(CommonFields):
    academic_year = models.ForeignKey(AcademicYear, related_name='candidate_programmemap_academic', on_delete=models.PROTECT)
    candidate = models.ForeignKey(CandidateProgrammeMap, related_name='candidate_programmemap_candidate', on_delete=models.PROTECT)
    batch_master = models.ForeignKey(BatchDetail, related_name='candidate_programmemap_batch', on_delete=models.PROTECT)


    class Meta:
         app_label = 'candidate_management'
         unique_together = ('batch_master', 'candidate')
        

    def __str__(self):
        return "%s - %s" %(self.batch_master, self.candidate)

class CandidateClassMap(CommonFields):
    candidate_batch = models.ForeignKey(CandidateBatchMap, related_name='candidate_classmap_candidate', on_delete=models.PROTECT)
    subject_batch_map = models.ForeignKey(SubjectBatchMap, related_name='candidate_classmap_subject_batch', on_delete=models.PROTECT)

    class Meta:
         app_label = 'candidate_management'
         unique_together = ('candidate_batch', 'subject_batch_map')
        

    def __str__(self):
        return "%s - %s" %(self.candidate_batch, self.subject_batch_map)
