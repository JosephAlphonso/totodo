from django.db.models.signals import post_delete
from django.dispatch import receiver
from .models import ParentDetail,CandidateDetail


@receiver(post_delete, sender=CandidateDetail)
@receiver(post_delete, sender=ParentDetail)
def post_delete_user(sender, instance, *args, **kwargs):
    if instance.user:
        instance.user.delete()