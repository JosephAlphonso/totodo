from django.shortcuts import render
from django.contrib.auth.models import User
from django.views.generic.base import View
from django.http import HttpResponse,JsonResponse
import notifications
from notifications.signals import notify

from django.core import serializers
import json
import timeago, datetime
import dateutil.parser
from notifications.models import Notification


class WebNotifications(View):
    
    def get(self, request):
        context = {}
        if request.user:
            username = request.user.username
        else:
            username = "please login"

        if request.user.is_anonymous:
            return render(request, 'notifications-view.html', {"notificationlist": []})
            
        user_obj = User.objects.get(pk=request.user.id)
        all_notifications = user_obj.notifications.all()

        l = []
        data = serializers.serialize("json", all_notifications)
        data = json.loads(data)
        date = datetime.datetime.now()

        for item in data:
            extra_fields = item["fields"]["data"]
            if extra_fields:
                obj = json.loads(extra_fields)
                tm = obj.get("noww")
                datetime_obj = dateutil.parser.parse(tm)
                sender = item["fields"]["actor_object_id"] 
                dict = {}
                
                dict["field"] = item["fields"]
                dict["field"]["sender_name"] = User.objects.get(pk=sender).username       
                dict["field"]["pk"] = item["pk"]
                dict["field"]["datatime"] = item["fields"]["timestamp"].split('T')[0]
                # dict["field"]["time"] = 
                dict["field"]["custom_ago"] = timeago.format(datetime_obj, date)
                dict["field"]["slug"] = notifications.utils.id2slug(item["pk"])
                dict["field"]["view_status"] = dict["field"]["unread"]
                l.insert(0, dict)
        return render(request, 'notifications-view.html', {"notificationlist":reversed(l)})
