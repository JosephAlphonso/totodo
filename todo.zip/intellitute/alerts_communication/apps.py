from django.apps import AppConfig


class AlertsCommunicationConfig(AppConfig):
    name = 'alerts_communication'
