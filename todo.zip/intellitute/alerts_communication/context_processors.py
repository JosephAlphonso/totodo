import notifications
from notifications.signals import notify
from django.http import JsonResponse
from django.contrib.auth.models import User
from notifications.models import Notification

from django.core import serializers
import json
import datetime
import timeago
import dateutil.parser



def notification_list(request):
    user = request.user
    # import ipdb; ipdb.set_trace()
    if user.is_anonymous():
        return {'notificationlist': 'annynomous'}
    else:
        user = User.objects.get(username=request.user)
        unread = user.notifications.unread()
        
        l = []
        data = serializers.serialize("json", unread)
        data = json.loads(data)
        date = datetime.datetime.now()

        for item in data:
            extra_fields = item["fields"]["data"]
            if extra_fields:
               obj = json.loads(extra_fields)
               tm = obj.get("noww")
               datetime_obj = dateutil.parser.parse(tm)
               sender = item["fields"]["actor_object_id"] 
               dict = {}
               dict["field"] = item["fields"]
               dict["field"]["sender_name"] = User.objects.get(pk=sender).username       
               dict["field"]["pk"] = item["pk"]
               dict["field"]["datatime"] = item["fields"]["timestamp"].split('T')[0]
               dict["field"]["custom_ago"] = timeago.format(datetime_obj, date)
               dict["field"]["slug"] = notifications.utils.id2slug(item["pk"])
               l.insert(0, dict)
        return {"notifications_list": reversed(l[-5:])}