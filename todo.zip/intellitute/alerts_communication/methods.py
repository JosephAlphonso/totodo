from django.http import HttpResponse,JsonResponse
from django.contrib.auth.models import User
from notifications.signals import notify
import notifications
import datetime
from django.contrib.auth.models import User

def sendNotificationTo(sender,reciever,msg):
    try:
        notify.send(User.objects.get(pk=sender), recipient=User.objects.get(pk=reciever),verb=msg,noww=datetime.datetime.now())
        return JsonResponse({"status_code":"200", "message":"successfully sent"})
    except Exception as err:
        return JsonResponse({"status_code":"500","message":"user may not exist"})