
from django.conf.urls import *
from alerts_communication import views
from django.contrib import admin

urlpatterns = [
   url(r'^web_notifications/$',views.WebNotifications.as_view(), name="web_notifications"),
]
