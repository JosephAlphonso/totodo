default_app_config = 'allauth.account.apps.AccountConfig'
