# -*- coding: utf-8 -*-
import requests

from allauth.socialaccount import app_settings
from allauth.socialaccount.models import SocialLogin, SocialToken
from allauth.socialaccount.providers.giis_auth.provider import GIISProvider
from allauth.socialaccount.providers.oauth2.views import (
    OAuth2Adapter,
    OAuth2CallbackView,
    OAuth2LoginView,
    OAuth2View,
)
from django.utils import timezone
from datetime import timedelta

from django.views.decorators.csrf import csrf_exempt
from allauth.account.adapter import DefaultAccountAdapter


class GIISOAuth2Adapter(OAuth2Adapter):

    provider_id = GIISProvider.id
    supports_state = True

    settings = app_settings.PROVIDERS.get(provider_id, {})
    provider_base_url = settings.get("GIIS_URL")
    authorize_base_url = settings.get('AUTHORIZE_URL')
    profile_base_url = settings.get('PROFILE_URL')
    access_token_base_url = settings.get('ACCESS_TOKEN_URL')
    
    access_token_method = 'GET'
    access_token_url = '{0}{1}'.format(provider_base_url, access_token_base_url)
    authorize_url = '{0}{1}'.format(provider_base_url,authorize_base_url)
    profile_url = '{0}{1}'.format(provider_base_url,profile_base_url)

    def complete_login(self, request, app, token, response):
        headers = {'Authorization':'Bearer %s' %token.token}
        extra_data = requests.get(self.profile_url, headers=headers).json()
        user_info = extra_data.get('GSFIdentity').split('|')
        extra_data = {
            'id_token': request.POST.get('id_token'),
            'user_code' : extra_data.get('UserCode'),
            'user_id' : user_info[0],
            'id' : user_info[0],
            'username' : user_info[0],
            'user_type' : user_info[2],
            'first_name' : user_info[3],
            'last_name' : user_info[4],
            'campus' : user_info[5],
            'unique_code' : user_info[6],
        }

        return self.get_provider().sociallogin_from_response(
            request,
            extra_data
        )

    def parse_token(self, data):
        token = SocialToken(token=data.get('access_token'))
        token.token_secret = data.get('refresh_token', '')
        expires_in = data.get('expires_in', None)
        if expires_in:
            token.expires_at = timezone.now() + timedelta(
                seconds=int(expires_in))
        return token
    
    def get_access_token(asd):
        import ipdb;ipdb.set_trace()
        pass

# class GIISAdapter(DefaultAccountAdapter):

#     def logout(self, request):
#         import ipdb;ipdb.set_trace()
#         pass


oauth2_login = OAuth2LoginView.adapter_view(GIISOAuth2Adapter)
oauth2_callback = OAuth2CallbackView.adapter_view(GIISOAuth2Adapter)

