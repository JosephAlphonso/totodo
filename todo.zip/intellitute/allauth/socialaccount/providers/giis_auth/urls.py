# -*- coding: utf-8 -*-
from allauth.socialaccount.providers.giis_auth.provider import GIISProvider
from allauth.socialaccount.providers.oauth2.urls import default_urlpatterns


urlpatterns = default_urlpatterns(GIISProvider)
