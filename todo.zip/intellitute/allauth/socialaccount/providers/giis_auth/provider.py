# -*- coding: utf-8 -*-
from allauth.socialaccount.providers.base import ProviderAccount
from allauth.socialaccount.providers.oauth2.provider import OAuth2Provider


class GIISAccount(ProviderAccount):

    def get_avatar_url(self):
        return self.account.extra_data.get('picture')

    def to_str(self):
        dflt = super(GIISAccount, self).to_str()
        return self.account.extra_data.get('name', dflt)


class GIISProvider(OAuth2Provider):
    id = 'giis_auth'
    name = 'GIIS'
    account_class = GIISAccount

    def get_default_scope(self):
        return ['openid', 'profile', 'login', 'offline_access']

    def extract_uid(self, data):
        return str(data['id'])

    def extract_common_fields(self, data):
        return dict(
            email=data.get('email'),
            username=data.get('username'),
            name=data.get('name'),
            user_id=data.get('user_id'),
            picture=data.get('picture'),
            access_token=data.get('access_token'),
            id_token=data.get('id_token'),
        )

    def get_auth_params(self, request, action):
        settings = self.get_settings()
        ret = dict(settings.get('AUTH_PARAMS', {}))
        dynamic_auth_params = request.GET.get('auth_params', None)
        ret['nonce'] = request.COOKIES.get('csrftoken')
        if dynamic_auth_params:
            ret.update(dict(parse_qsl(dynamic_auth_params)))
        return ret

provider_classes = [GIISProvider]
