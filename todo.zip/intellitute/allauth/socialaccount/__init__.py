default_app_config = 'allauth.socialaccount.apps.SocialAccountConfig'
